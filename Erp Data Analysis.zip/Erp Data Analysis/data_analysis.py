import mysql.connector
import pandas as pd

# Connect to MySQL (phpMyAdmin)
conn = mysql.connector.connect(
    host="localhost",             # or 127.0.0.1
    user="root",                  # default phpMyAdmin user
    password="",                  # add password if you set one
    database="erp_export_analysis"
)

# Load all tables
customers = pd.read_sql("SELECT * FROM customers", conn)
products = pd.read_sql("SELECT * FROM products", conn)
sales_orders = pd.read_sql("SELECT * FROM sales_orders", conn)
inventory = pd.read_sql("SELECT * FROM inventory", conn)

conn.close()

print("✅ Data loaded successfully!")

# Merge sales data with customers and products
sales_data = sales_orders.merge(customers, on='customer_id') \
                         .merge(products, on='product_id')

# Inspect the column names of the merged sales_data
print(sales_data.columns)

# Perform data analysis
sales_data['sales_amount'] = sales_data['quantity'] * sales_data['price']
sales_data['order_date'] = pd.to_datetime(sales_data['order_date'])
sales_data['month'] = sales_data['order_date'].dt.to_period('M')

# Sales per customer using 'name_x' (customer name)
sales_per_customer = sales_data.groupby('name_x')['sales_amount'].sum().sort_values(ascending=False)

# Monthly revenue calculation
monthly_revenue = sales_data.groupby('month')['sales_amount'].sum()

# Top products sold based on quantity using 'name_y' (product name)
top_products = sales_data.groupby('name_y')['quantity'].sum().sort_values(ascending=False)

# Inventory turnover ratio
inventory_turnover = sales_data.groupby('product_id')['quantity'].sum().reset_index()
inventory_turnover = inventory_turnover.merge(inventory, on='product_id')
inventory_turnover['turnover_ratio'] = inventory_turnover['quantity'] / inventory_turnover['current_stock']

# Identify low stock items (less than 150 units)
low_stock = inventory[inventory['current_stock'] < 150]

# Export to Excel
import os
if not os.path.exists("output"):
    os.makedirs("output")

with pd.ExcelWriter("output/export_analysis_report.xlsx", engine="openpyxl") as writer:
    customers.to_excel(writer, sheet_name="Customers", index=False)
    products.to_excel(writer, sheet_name="Products", index=False)
    sales_orders.to_excel(writer, sheet_name="Sales Orders", index=False)
    inventory.to_excel(writer, sheet_name="Inventory", index=False)
    sales_data.to_excel(writer, sheet_name="Merged Sales Data", index=False)
    sales_per_customer.to_frame("Total Sales").to_excel(writer, sheet_name="Sales per Customer")
    monthly_revenue.to_frame("Monthly Revenue").to_excel(writer, sheet_name="Monthly Revenue")
    top_products.to_frame("Units Sold").to_excel(writer, sheet_name="Top Products")
    inventory_turnover.to_excel(writer, sheet_name="Inventory Turnover", index=False)
    low_stock.to_excel(writer, sheet_name="Low Stock Alerts", index=False)

print("✅ Excel report generated: output/export_analysis_report.xlsx")






import matplotlib.pyplot as plt
import seaborn as sns

# Sales per Customer (Bar chart)
plt.figure(figsize=(12, 6))
sales_per_customer.plot(kind='bar', color='skyblue')
plt.title("Sales per Customer")
plt.xlabel("Customer Name")
plt.ylabel("Total Sales")
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()

# Monthly Revenue (Line chart)
plt.figure(figsize=(12, 6))
monthly_revenue.plot(kind='line', color='green', marker='o')
plt.title("Monthly Revenue")
plt.xlabel("Month")
plt.ylabel("Revenue")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# Top Products (Bar chart)
plt.figure(figsize=(12, 6))
top_products.plot(kind='bar', color='orange')
plt.title("Top Products by Quantity Sold")
plt.xlabel("Product Name")
plt.ylabel("Quantity Sold")
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()

