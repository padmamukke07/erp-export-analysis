
-- Database: erp_export_analysis

-- Drop existing tables if they exist
DROP TABLE IF EXISTS sales_orders;
DROP TABLE IF EXISTS inventory;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS customers;

-- Table: customers
CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    name VARCHAR(100),
    country VARCHAR(50)
);

INSERT INTO customers VALUES 
(1, 'Global Traders Ltd', 'USA'),
(2, 'Sunrise Impex', 'India'),
(3, 'Pacific Exports', 'Australia'),
(4, 'Nova Distributors', 'UK');

-- Table: products
CREATE TABLE products (
    product_id INT PRIMARY KEY,
    name VARCHAR(100),
    category VARCHAR(50),
    price DECIMAL(10,2)
);

INSERT INTO products VALUES
(101, 'Cotton Shirts', 'Apparel', 15.00),
(102, 'Denim Jeans', 'Apparel', 25.00),
(103, 'Silk Saree', 'Textile', 40.00),
(104, 'Jute Bags', 'Accessories', 10.00);

-- Table: sales_orders
CREATE TABLE sales_orders (
    order_id INT PRIMARY KEY,
    customer_id INT,
    product_id INT,
    order_date DATE,
    quantity INT,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

INSERT INTO sales_orders VALUES
(201, 1, 101, '2024-10-01', 200),
(202, 2, 103, '2024-10-03', 50),
(203, 3, 104, '2024-10-05', 100),
(204, 4, 102, '2024-10-08', 150),
(205, 1, 101, '2024-10-12', 300),
(206, 3, 103, '2024-10-15', 80),
(207, 2, 104, '2024-10-18', 70);

-- Table: inventory
CREATE TABLE inventory (
    product_id INT PRIMARY KEY,
    current_stock INT,
    last_restocked DATE,
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

INSERT INTO inventory VALUES
(101, 500, '2024-09-25'),
(102, 250, '2024-09-20'),
(103, 120, '2024-09-15'),
(104, 300, '2024-09-28');
